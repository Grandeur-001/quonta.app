const cryptoData = [
    {
        id: '1',
        symbol: 'BTC',
        name: 'Bitcoin',
        imageUrl: 'https://s2.coinmarketcap.com/static/img/coins/64x64/1.png',
        data_value: 'BTC'
      },
      {
        id: '2',
        symbol: 'USDT',
        name: 'Tether',
        imageUrl: 'https://s2.coinmarketcap.com/static/img/coins/64x64/825.png',
        data_value: 'USDT'
      },
      {
        id: '3', 
        symbol: 'ETH',
        name: 'Ethereum',
        imageUrl: 'https://s2.coinmarketcap.com/static/img/coins/64x64/1027.png',
        data_value: 'ETH'
      },
      {
        id: '5',
        symbol: 'DOGE',
        name: 'Dogecoin',
        imageUrl: 'https://s2.coinmarketcap.com/static/img/coins/64x64/74.png',
        data_value: 'DOGE'
      },
      {
        id: '6',
        symbol: 'BNB',
        name: 'Binance Coin',
        imageUrl: 'https://s2.coinmarketcap.com/static/img/coins/64x64/1839.png',
        data_value: 'BNB'
      },
      {
        id: '8',
        symbol: 'SHIB',
        name: 'Shiba Inu',
        imageUrl: 'https://s2.coinmarketcap.com/static/img/coins/64x64/5994.png',
        data_value: 'SHIB'
      },
      {
        id: '9',
        symbol: 'LTC',
        name: 'Litecoin',
        imageUrl: 'https://s2.coinmarketcap.com/static/img/coins/64x64/2.png',
        data_value: 'LTC'
    
      },
      {
        id: '10',
        symbol: 'XRP',
        name: 'Ripple',
        imageUrl: 'https://s2.coinmarketcap.com/static/img/coins/64x64/52.png',
        data_value: 'XRP'
    
      }
];






